GEEXUX SHOP
============

Open index.html in a browser to preview the shop.

This version includes:
- Luxury dark/gold design
- Electronics, clothes, shoes and bags
- Product catalogue and category filtering
- Shopping cart
- KES prices
- Demo M-Pesa checkout

IMPORTANT:
The M-Pesa section is only a demo. It does not process real payments.
For real M-Pesa payments, the shop needs a secure backend and an approved payment integration.
